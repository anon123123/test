<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Super Chat temps réel !</title>
        <style>
            #zone_chat strong {
                color: white;
                background-color: black;
                padding: 2px;
            }
        </style>
    </head>
 
    <body>
        <h1>bienvenu au chat</h1>

        <form action="/" method="post" id="formulaire_chat" method="post" onsubmit="return validateForm()">
            <input type="text" name="user" id="user" placeholder="username" size="50" autofocus />
			<input type="text" name="pw" id="pw" placeholder="mot de passe" size="50" />
            <input type="submit" id="envoi_message" value="Envoyer" />
        </form>
		
    </body>
</html>

<script>
function validateForm() {
  var user = document.forms["formulaire_chat"]["user"].value;
  var pw = document.forms["formulaire_chat"]["pw"].value;
  
  if (user == "etudiant" && pw == "password") {
	window.location.replace("etudiant.html");
  }
  else if(user == "prof" && pw == "password"){
	window.location.replace("prof.html");
  }
}	
</script>