<?php

include ("../DataAccessLayer/clientVO.php" );
include ("../DataAccessLayer/ClientDAO.php" );
#$client = new ClientVO();
$clientDAO = new ClientDAO();
$client = $clientDAO->getClient();
// for (i=0;i<sizeof($client);i++){
	// //creation d'un objet VO a retourner
	// $client[i]->getID();
	// $client[i]->getNom();
	// $client[i]->getAdresse();
	// $client[i]->getVille();
	// $client[i]->getPays();
	// $client[i]->getTelephone();
// }

?>

<html>

<meta charset="utf-8"/>
<head>
	<title>Verifier une commande</title>
	<link rel="stylesheet" href="Styles/style.css">
</head>
<body>
	<div class = "titleBox">
        <a href="../index.html" id="indexPage">
          <img src = "../Images/logo.png"
               alt = "logo wines of canada"
               style = "width:100px;height:130px">
        </a>
        
	</div>


       <h1>Liste de commandes actifs</h1>
       <div class = "whiteBox" >
        <div class = "identificationBox" >
        <table style="width:40%">
  <tr>
    <th>#Commande</th>
    <th>Nom</th> 
	<th>Description</th>
  </tr>
  <?php
  for($i=0;$i<sizeof($client);$i++){
  ?>
	  <tr>
		<td><?php echo $client[$i]->getNum()?></td>
		<td><?php echo $client[$i]->getNom()?></td> 
		<td><?php echo $client[$i]->getDescription()?></td>
	  </tr>
	<?php
  }
  ?>

      </div>

	</div>
	

</body>
</html>




