
<?php
class ClientDAO
{
	protected $pdo;
	
	//methode d'initialisation de la bande de donnees
	public function ClientDAO()
	{
		try{
			$strConnection = 'mysql:host=localhost;dbname=devoirweb';
			$arrAutresParam = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",PDO::MYSQL_ATTR_INIT_COMMAND =>"SET CHARACTER SET utf8");
			$this->pdo= new PDO($strConnection, 'root', '', $arrAutresParam);
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
		}catch (PDOException $pdoe){
			$message = 'ERREUR PDO dans ' . $pdoe->getFile(). 'Ligne' . $pdoe-> getLine() . ' : ' . $pdoe->getMessage();
			die($message);
		}
	}
	//Creation d'un client selon l'objet clientVO passe en param
	public function Create_Client(ClientVO $client)
	{
		$query = "INSERT INTO client (Prenom, Nom, DateNaissance, Adresse, Description, Telephone) "
			. "VALUES( '" . $client->getPrenom()
			. "','" . $client->getNom()
			. "','" . $client->getDateNaissance()
			. "','" . $client->getAdresse()
			. "','" . $client->getDescription()
			. "','" . $client->getTel() . "');";
		
		$prep = $this->pdo->prepare($query);
		$prep->execute();
	}
	
	//Methode retournant une table d'objet ClientVO
	public function getClient()
	{
		$query = "SELECT * FROM client;";
		$prep = $this->pdo->prepare($query);
		$prep->execute();
		$array = $prep->fetchAll(PDO::FETCH_OBJ);
		if(sizeof($array) > 0){
			for ($i=0;$i<sizeof($array);$i++){
				//creation d'un objet VO a retourner
				$client[$i] = new ClientVO();
				$client[$i]->setNum($array[$i]->NumeroClient);
				$client[$i]->setPrenom($array[$i]->Prenom);
				$client[$i]->setNom($array[$i]->Nom);
				$client[$i]->setDateNaissance($array[$i]->DateNaissance);
				$client[$i]->setAdresse($array[$i]->Adresse);
				$client[$i]->setDescription($array[$i]->Description);
				$client[$i]->setTel($array[$i]->Telephone);
			}
		}
		return $client;
	}
}
?>