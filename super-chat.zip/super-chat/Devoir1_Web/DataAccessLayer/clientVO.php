<?php
class ClientVO{
	
	protected $num;
	protected $prenom;
	protected $nom;
	protected $dateNaissance;
	protected $adresse;
	protected $description;
	protected $tel;
	
	public function getNum(){
		return $this->num;
	}
	public function setNum($num){
		$this->num = $num;
	}
	public function getPrenom(){
		return $this->prenom;
	}
	public function setPrenom($prenom){
		$this->nom = $prenom;
	}
	
	public function getNom(){
		return $this->nom;
	}
	public function setNom($nom){
		$this->nom = $nom;
	}
	
	public function getDateNaissance(){
		return $this->dateNaissance;
	}
	public function setDateNaissance($dateNaissance){
		$this->dateNaissance = $dateNaissance;
	}
	public function getAdresse(){
		return $this->adresse;
	}
	public function setAdresse($adresse){
		$this->adresse = $adresse;
	}
	
	public function getDescription(){
		return $this->description;
	}
	public function setDescription($description){
		$this->description = $description;
	}
	
	public function getTel(){
		return $this->tel;
	}
	public function setTel($tel){
		$this->tel = $tel;
	}
}	
?>