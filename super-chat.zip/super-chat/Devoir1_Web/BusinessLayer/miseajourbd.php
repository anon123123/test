<?php

include ("../DataAccessLayer/clientVO.php" );
include ("../DataAccessLayer/ClientDAO.php" );

$clientVO = new ClientVO();
$clientDAO = new ClientDAO();
if(isset($_POST['txtPrenom']))
$clientVO->setPrenom($_POST['txtPrenom']);

if(isset($_POST['txtNom']))
$clientVO->setNom($_POST['txtNom']);

if(isset($_POST['txtDateNaissance']))
$clientVO->setDateNaissance($_POST['txtDateNaissance']);

if(isset($_POST['txtAdresse']))
$clientVO->setAdresse($_POST['txtAdresse']);

if(isset($_POST['txtDescription']))
$clientVO->setDescription($_POST['txtDescription']);

if(isset($_POST['txtTel']))
$clientVO->setTel($_POST['txtTel']);


$clientDAO ->Create_Client($clientVO);





?>



<html>
<meta charset="utf-8"/>
<head>
	<title>Information de commande</title>
	<link rel="stylesheet" href="../Styles/style.css">
</head>
<body>
 <div class = "titleBox">
        <a href="../index.html" id="indexPage">
          <img src = "../Images/logo.png"
               alt = "logo wines of canada"
               style = "width:100px;height:130px">
        </a>
        
  </div>

	  <div class = "whiteBox" >
       <h1>Resume de commande</h1>
       <div class = "whiteBox" >
        <div class = "identificationBox" >
        <p>Information du client</p>  
        <p>Pr&eacute;nom: <?php echo $_POST['txtPrenom']?></p>
		<p>Nom: <?php echo $_POST['txtNom']?></p>
		<p>Date de naissance: <?php echo $_POST['txtDateNaissance']?></p>
		<p>Adresse: <?php echo $_POST['txtAdresse']?></p>
		<p>Description: <?php echo $_POST['txtDescription']?></p>
		<p>T&eacute;l&eacute;phone: <?php echo $_POST['txtTel']?></p>
		<p>Commande envoy&eacute; le :<?php echo date("Y/m/d")." a ". date("h:i:sa") ;?></p>
        </div>
		
<!--
       <h1>Liste de commandes en cours</h1>
       <div class = "whiteBox" >
        <div class = "identificationBox" >
        <table style="width:40%">
  <tr>
    <th>#Commande</th>
    <th>Nom</th> 
	<th>Description</th>
  </tr>
	<?php $client = $clientDAO->getClient();?>
	  <tr>
		<td><?php echo $client[sizeof($client)]->getNum()?></td>
		<td><?php echo $client[sizeof($client)]->getNom()?></td> 
		<td><?php echo $client[sizeof($client)]->getDescription()?></td>
	  </tr>-->

       <h2>Merci d'avoir utilis&eacute; les services Sanschagrin!</h2>
       </div>
      </div>

</body>
</html>
