function showAlert()
{
	alert("Votre commande est soumise, merci!");
}