var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    ent = require('ent'), // Permet de bloquer les caractères HTML (sécurité équivalente à htmlentities en PHP)
    fs = require('fs');
	//var express = require('express');
	//var app2 = express();
	app.use('/Styles', require('express').static('Styles'));
	app.use('/Images', require('express').static('Images'));
	app.use('/JavaScript', require('express').static('JavaScript'));

// Chargement de la page index.html
app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

// Chargement de la page etudiant.html
app.get('/etudiant', function (req, res) {
  res.sendfile(__dirname + '/etudiant.html');
});

// Chargement de la page prof.html
app.get('/prof', function (req, res) {
  res.sendfile(__dirname + '/prof.html');
});

io.sockets.on('connection', function (socket, pseudo) {
    // Dès qu'on nous donne un pseudo, on le stocke en variable de session et on informe les autres personnes
    socket.on('nouveau_client', function(pseudo) {
        pseudo = ent.encode(pseudo);
        socket.pseudo = pseudo;
        socket.broadcast.emit('nouveau_client', pseudo);
    });

    // Dès qu'on reçoit un message, on récupère le pseudo de son auteur et on le transmet aux autres personnes
    socket.on('message', function (message) {
        message = ent.encode(message);
        socket.broadcast.emit('message', {pseudo: socket.pseudo, message: message});
    }); 
});

server.listen(8080);
